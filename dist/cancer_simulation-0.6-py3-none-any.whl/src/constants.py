"""global constants"""

SCREEN_HEIGHT = 900
SCREEN_WIDTH = 1600

BUTTON_HEIGHT = 100
BUTTON_WIDTH = 100
BUTTON_ADD = "./assets/icons8-add-100.png"
BUTTON_START = "./assets/icons8-watermelon-100.png"
BUTTON_STOP = "./assets/icons8-cancel-138.png"

BLOCK_SIZE_DIVISIBLE = 500
